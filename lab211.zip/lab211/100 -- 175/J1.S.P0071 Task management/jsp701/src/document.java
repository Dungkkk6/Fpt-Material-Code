/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author dungvnzx1
 */
public class document {
    /*
    
    
    
  src
└── your.package.name
    ├── input
    │   └── InputGetter.java
    ├── main
    │   └── Main.java
    ├── task
    │   ├── Task.java
    │   ├── TaskManager.java
    │   └── TaskType.java
    └── validation
        └── Validation.java

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    */
}
