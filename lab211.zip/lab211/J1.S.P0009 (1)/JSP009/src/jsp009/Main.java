/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jsp009;

/**
 *
 * @author dungvnzx1
 */
public class Main {

  
    public static void main(String[] args) {
         Array arrFibo = new Array(); 
         arrFibo.generateFibonancii(0, 0, 1);
         arrFibo.display();
    }
    
}
