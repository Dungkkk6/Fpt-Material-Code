/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
// package service;


// import java.io.*;
// import java.util.List;

// public class FileHandler {
//     public static <T> void saveToFile(String fileName, List<T> data) throws IOException {
//         try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
//             oos.writeObject(data);
//         }
//     }

//     public static <T> List<T> readFromFile(String fileName) throws IOException, ClassNotFoundException {
//         try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName))) {
//             return (List<T>) ois.readObject();
//         }
//     }
// }
